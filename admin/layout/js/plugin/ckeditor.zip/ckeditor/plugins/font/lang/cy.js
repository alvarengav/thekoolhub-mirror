﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'cy', {
	fontSize: {
		label: 'Maint',
		voiceLabel: 'Maint y Ffont',
		panelTitle: 'Maint y Ffont'
	},
	label: 'Ffont',
	panelTitle: 'Enw\'r Ffont',
	voiceLabel: 'Ffont'
} );
