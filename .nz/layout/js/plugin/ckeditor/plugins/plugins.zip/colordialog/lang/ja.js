﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'ja', {
	clear: 'クリア',
	highlight: 'ハイライト',
	options: 'カラーオプション',
	selected: '選択された色',
	title: '色選択'
} );
