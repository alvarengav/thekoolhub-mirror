/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'bg', {
	alt: 'Алтернативен текст',
	border: 'Рамка',
	btnUpload: 'Изпрати я на сървъра',
	button2Img: 'Do you want to transform the selected image button on a simple image?', // MISSING
	hSpace: 'Хоризонтален отстъп',
	img2Button: 'Do you want to transform the selected image on a image button?', // MISSING
	infoTab: 'Инфо за снимка',
	linkTab: 'Връзка',
	lockRatio: 'Заключване на съотношението',
	menu: 'Настройки за снимка',
	resetSize: 'Нулиране на размер',
	title: 'Настройки за снимка',
	titleButton: 'Настойки за бутон за снимка',
	upload: 'Качване',
	urlMissing: 'Image source URL is missing.', // MISSING
	vSpace: 'Вертикален отстъп',
	validateBorder: 'Border must be a whole number.', // MISSING
	validateHSpace: 'HSpace must be a whole number.', // MISSING
	validateVSpace: 'VSpace must be a whole number.' // MISSING
} );
