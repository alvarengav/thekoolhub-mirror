﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'fr-ca', {
	clear: 'Effacer',
	highlight: 'Surligner',
	options: 'Options de couleur',
	selected: 'Couleur sélectionnée',
	title: 'Choisir une couleur'
} );
