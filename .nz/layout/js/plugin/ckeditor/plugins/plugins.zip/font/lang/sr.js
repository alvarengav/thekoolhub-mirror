﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'font', 'sr', {
	fontSize: {
		label: 'Величина фонта',
		voiceLabel: 'Font Size',
		panelTitle: 'Величина фонта'
	},
	label: 'Фонт',
	panelTitle: 'Фонт',
	voiceLabel: 'Фонт'
} );
