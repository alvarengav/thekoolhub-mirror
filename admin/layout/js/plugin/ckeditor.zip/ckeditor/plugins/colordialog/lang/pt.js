﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'colordialog', 'pt', {
	clear: 'Limpar',
	highlight: 'Realçar',
	options: 'Opções de cor',
	selected: 'Cor selecionada',
	title: 'Selecionar cor'
} );
